<div class="row">
    <div class="col-xs-12 col-lg-4" style="min-width: 350px;">
        <a href="#" class="thumbnail text-center" style="border: none;">
            <h4>How register a client</h4>
                <iframe src="https://www.youtube.com/embed/MA240SwOsxU" frameborder="0" allowfullscreen></iframe>
            <p>There is a sample way to register a client please follow the video tutorial!</p>
        </a>
    </div><!--/.col-xs-6.col-lg-4-->

    <div class="col-xs-12 col-lg-4" style="min-width: 350px;">
        <a href="#" class="thumbnail text-center" style="border: none;">
            <h4>How register a client</h4>
            <iframe src="https://www.youtube.com/embed/RAEAHq2ey_8" frameborder="0" allowfullscreen></iframe>
            <p>There is a sample way to register a client please follow the video tutorial!</p>
        </a>
    </div><!--/.col-xs-6.col-lg-4-->

    <div class="col-xs-12 col-lg-4" style="min-width: 350px;">
        <a href="#" class="thumbnail text-center" style="border: none;">
            <h4>How register a client</h4>
            <iframe src="https://www.youtube.com/embed/uAWfZhxNak0" frameborder="0" allowfullscreen></iframe>
            <p>There is a sample way to register a client please follow the video tutorial!</p>
        </a>
    </div><!--/.col-xs-6.col-lg-4-->

</div>