@yield('main-content')

@section('scripts')
    @include('layouts.partials.scripts')
@show