 Hi {{$name}}  
 <p>Your registration is completed. please click the link ot get access. </p>
{{route('confirmation', $token)}} 
