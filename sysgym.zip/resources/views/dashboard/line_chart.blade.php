<canvas id="lineChart" style="height:230px"></canvas>
