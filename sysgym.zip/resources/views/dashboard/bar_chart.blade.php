<canvas id="barChart" style="height:230px"></canvas>
