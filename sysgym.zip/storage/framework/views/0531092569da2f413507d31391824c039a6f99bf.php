<?php $__env->startSection('htmlheader_title'); ?>
	<?php echo e(trans('adminlte_lang::message.employees')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
  <?php echo e(trans('adminlte_lang::message.app_name')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_description'); ?>
  <?php echo e(trans('adminlte_lang::message.employees')); ?>

<?php $__env->stopSection(); ?>
<?php
$status = [trans('adminlte_lang::message.deleted'),trans('adminlte_lang::message.active'),trans('adminlte_lang::message.expired')];
$status_color = ['danger','success','info'];
?>


<?php $__env->startSection('main-content'); ?>
	<div class="row">
	    <div class="col-lg-12">
	        <div class="box box-primary">
	            <div class="box-header with-border">
	              <h3 class="box-title"> <?php echo e(trans('adminlte_lang::message.employees_list')); ?></h3>
	              <div class="pull-left box-tools">
                        
                          <a href="<?php echo e(url('employees/create')); ?>" class="btn btn-primary btn-sm" role="button" data-toggle="tooltip" title="<?php echo e(trans('adminlte_lang::message.new_employee')); ?>">
                               <i class="fa fa-plus"></i> <?php echo e(trans('adminlte_lang::message.new_employee')); ?>

                          </a>
                        
	              </div><!-- /. tools -->
	            </div><!-- /.box-header -->

	            <div class="box-body">
	                <table id="table-employee" class="table table-hover table-design">
		                <thead>
		                  <tr>
		                    
						  	<th class="col-md-1"><?php echo e(trans('adminlte_lang::message.category')); ?></th>
						  	<th class="col-md-2"><?php echo e(trans('adminlte_lang::message.name')); ?></th>
						  	<th class="col-md-2"><?php echo e(trans('adminlte_lang::message.email')); ?></th>
		                    <th class="col-md-2"><?php echo e(trans('adminlte_lang::message.contacts')); ?></th>
                            <th class="col-md-1"><?php echo e(trans('adminlte_lang::message.genre')); ?></th>
                              <th class="col-md-2"><?php echo e(trans('adminlte_lang::message.address')); ?></th>
                          <th class="col-md-1"><?php echo e(trans('adminlte_lang::message.status')); ?></th>
		                    <th class="col-md-1"></th>
		                  </tr>
		                </thead>
		                <tbody>
                          <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr class="bg-<?php echo e($status_color[$employee->status]); ?>">
									<td><?php echo e($employee->employee_category->name); ?></td>
									<td><a href="#show" data-url="<?php echo e(route('employees.show',$employee->id)); ?>" id="people_show_popup" data-title="<?php echo e(trans('adminlte_lang::message.employee_details')); ?>"><?php echo e($employee->name); ?></a> </td>
									<td><?php echo e($employee->email); ?></td>
                                    <td><?php echo e($employee->mobile); ?> / <?php echo e($employee->phone); ?></td>
                                    <td><?php echo e(trans('adminlte_lang::message.'.$employee->genre)); ?></td>
                                    <td><?php echo e($employee->address); ?></td>
                                    <td><span class="label label-<?php echo e($status_color[$employee->status]); ?>"><?php echo e($status[$employee->status]); ?></span></td>
                                    <td>
										
											<a href="<?php echo e(route('employees.show',$employee->id)); ?>"  data-toggle="tooltip" title="<?php echo e(trans('adminlte_lang::message.show_details')); ?>">
												<i class="fa fa-eye"></i>
											</a>
										

                                        
											<a href="<?php echo e(route('employees.edit',$employee->id)); ?>"  data-toggle="tooltip" title="<?php echo e(trans('adminlte_lang::message.edit')); ?>" id="edit-employee" >
												<i class="fa fa-edit"></i>
                                            </a>
										

                                        
                                            <a href="#disable" style="display: <?php echo e($employee->status == 1 ? 'initial' :'none'); ?>;" data-toggle="tooltip" id="disable-employee" title="<?php echo e(trans('adminlte_lang::message.disable')); ?>" data-key="<?php echo e($employee->id); ?>" data-name="<?php echo e($employee->name); ?>">
                                                <i class="fa fa-user-o"></i>
                                            </a>
                                        

                                        
                                            <a href="#enable" style="display: <?php echo e($employee->status == 0 ? 'initial' :'none'); ?>;" data-toggle="tooltip" id="enable-employee" title="<?php echo e(trans('adminlte_lang::message.enable')); ?>" data-key="<?php echo e($employee->id); ?>" data-name="<?php echo e($employee->name); ?>">
                                                <i class="fa fa-user"></i>
                                            </a>
                                        

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		                <tbody>
                    </table>
	            </div>
	        </div>
	    </div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>