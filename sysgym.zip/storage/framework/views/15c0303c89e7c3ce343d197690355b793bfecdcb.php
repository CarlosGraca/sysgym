 Hi <?php echo e($name); ?>  
 <p>Your registration is completed. please click the link ot get access. </p>
<?php echo e(route('confirmation', $token)); ?> 
