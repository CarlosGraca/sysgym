<?php
header('Location: /');
?>