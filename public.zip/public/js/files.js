/**
 * Created by MS-INSYS on 23/02/2017.
 */

$(function () {

    $(document).on('click','#add-file',function (e) {
        e.preventDefault();
        var _file = $(':file');

        if(_file.val() == ''){
            toastr.error('no file browsed',{timeOut: 5000} ).css("width","500px");
        }
        else{
            save($('#files-form'), $('#files-form')[0], 'create');
        }
    });

    $(document).on('click','.file-preview',function (e) {
        e.preventDefault();
        $('#modal-ajax').css('overflow','auto');
        console.log(($(window).height() - 100));
        $('#modal-ajax').find('.modal-content').css('height',($(window).height() - 100)+'px');
        $('#modal-ajax').find('#myModalLabel').html('<i class="fa fa-eye"></i> ');
        $('#modal-ajax').find('#myModalLabel').append($(this).data('original-title'));

        $('#modal-ajax').find('.modal-body').load($(this).data('url'));
        var footer_html = $('#modal').find('.modal-body').find('#app_footer').html();
        $('#modal-ajax').find('.modal-footer').html(footer_html);

       // $('#modal').find('.modal-body').find('.preview-image').attr('style','max-height: 100%;height: 400px; width: auto; margin: 0 auto; z-index: -1;');

        $('#modal-ajax').modal();


        $('#modal-ajax').find('.modal-body').slimScroll({
            height: ($(window).height()-200)
        });
        $('#modal-ajax').find('.slimScrollDiv').attr('style','overflow: auto; height: '+($(window).height()-200)+'px;');

    });

    $(document).on('click','.file-remove',function (e) {
        e.preventDefault();

        // var _alert = confirm('Are you sure?');
        var _tr_element = $(this).parent().parent();
        var _this = $(this);

        bootbox.confirm({
            title: _confirm_alert_text,
            message: 'This action can not be undone',
            //size: 'small',
            buttons: {
                confirm: {
                    label: _yes_text,
                    className: 'btn-success'
                },
                cancel: {
                    label: _no_text,
                    className: 'btn-danger'
                }
            },
            callback: function (result) {
                if (result == true) {

                    // console.log(_this.attr('data-url'));
                    // if (_alert){
                    // remove_table_schedule_data(_element);
                    $.get(_this.attr('data-url'), function (data) {
                        // console.log(data.message);
                        _tr_element.remove();
                        toastr.success(data.message, {timeOut: 5000}).css("width", "300px");
                    }, "json");

                }else{

                }
            }
        });


    });
    
});


function file_table_data(value) {
    var table = $('#table-documents');

    /*
    *  <tr class="file_document" data-key="{{ $pfile->file->id }}">
     <td class="name_original"><a href="#">{{$pfile->file->name_original}} </a> </td>
     <td style="text-align: center" class="media_type">{{$pfile->file->media_type}}</td>
     <td>
     <a href="#" data-toggle="tooltip" title="{{ trans('adminlte_lang::message.view') }}" class="file-preview" data-url="{{ url('files') }}/{{$pfile->file->id}}/preview" style="visibility: {{ $pfile->file->media_type != 'doc' ? 'visible':'hidden' }};"><i class="fa fa-eye"></i>
     </a>
     <a href="{{ url('files') }}/{{$pfile->file->id}}/download" data-toggle="tooltip" title="{{ trans('adminlte_lang::message.download') }}" ><i class="fa fa-download"></i>
     </a>
     <a href="#" data-url="{{ url('files') }}/{{$pfile->file->id}}/remove" data-toggle="tooltip" title="{{ trans('adminlte_lang::message.remove') }}" class="file-remove"><i class="fa fa-trash"></i>
     </a>
     </td>
     </tr>
    * 
    * */

    var arr = ['jpeg', 'jpg', 'gif', 'png', 'pdf'];

    // console.log(value["media_type"]);
    // console.log($.inArray(value["media_type"],arr) );

    table.append(
        '<tr class="file_document" data-key="' + value["id"] + '">' +
        '<td class="name_original">' + value["name_original"] + '</td>' +
        '<td class="description">' + value["description"] + '</td>' +
        '<td class="media_type" style="text-align: center" >' + value["media_type"] + '</td>' +
        '<td class="action_button"> ' +
            '<a href="#!preview" class="file-preview" data-url="'+_file_url+'/'+value["id"]+'/preview" data-toggle="tooltip" title="'+_preview_text+'" style="visibility: ' + ( $.inArray(value["media_type"],arr)  != -1 ? "visible" : "hidden") +';" ><i class="fa fa-eye"></i></a> ' +
            '<a href="'+_file_url+'/'+value["id"]+'/download" class="edit_schedule" data-toggle="tooltip" title="'+_download_text+'"><i class="fa fa-download"></i></a> ' +
            '<a href="#!remove" class="file-remove" data-url="'+_file_url+'/'+value["id"]+'/remove" data-toggle="tooltip" title="'+_remove_text+'"><i class="fa fa-trash"></i></a> ' +
        '</td>' +
        '</tr>'
    );
}