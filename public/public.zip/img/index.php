<?php
header('Location: /');
?>